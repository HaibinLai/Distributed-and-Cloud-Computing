# RESTful API with CodeGen - FastAPI
Generating Python FastAPI code from an OpenAPI YAML file.

## Requirements
- Check `pyproject.toml` or `requirements.txt` in the `out/` folder for Python requirements. Set up with `uv sync`.
- Docker

> If you are not working with `uv`, then just run `python -m pip install -r requirements.txt`.

## Update OpenAPI Specification File
The `petstore.yaml` records the API specifications of how the client will interact with the server. We will use this file to generate a code stub for our backend server.

For more information on OpenAPI Specification, check here: https://swagger.io/specification/.

## Generate and Implement the Backend Server
With [Docker + OpenAPI Generator](https://openapi-generator.tech/#tryDocker), we can use the OpenAPI Generator CLI to generate code stubs for the Python FastAPI backend server.

Run the following command:
```docker
docker run --rm -v ./:/app/ openapitools/openapi-generator-cli generate \
    -i /app/petstore.yaml \
    -g python-fastapi \
    -o /app/out/
```

The outputs will appear in the local `out/` directory. Now you can implement the API functions based on this code structure. Basically, write something for the controllers (`apis/`) inside `src/openapi_server/`. **Note that this generator simply asks for concrete implementations of the base api classes inside the `impl/` folder.**

> Check PEP 487 `__init_classes__` hook ([here](https://peps.python.org/pep-0487/#proposal)) to understand more about why we just need to define a concrete subclass of `BasePetApi`.

**Inside the `out/` folder, remove the existing `pyproject.toml` file and run `uv init` to turn it into a uv project. Then, run `uv add -r requirements.txt` to update the uv environment with all specified dependencies.**

**After implementing everything, to avoid re-generation overwriting your current files, add the fixed files to `out/.openapi-generator-ignore`.**

## Run and Test the Backend Server
Check the `README.md` file inside the generated `out/` directory. To start a backend server for testing, simply run:

```bash
cd out
PYTHONPATH=src uv run uvicorn openapi_server.main:app --host 0.0.0.0 --port 8080
```

The server will serve on all network interfaces with port=`8080`. Below shows an output example:

```bash
# PYTHONPATH=src uv run uvicorn openapi_server.main:app --host 0.0.0.0 --port 8080
INFO:     Started server process [3920]
INFO:     Waiting for application startup.
INFO:     Application startup complete.
INFO:     Uvicorn running on http://0.0.0.0:8080 (Press CTRL+C to quit)
```

To test the APIs, you can use `curl`:

```bash
# Get all pets
curl http://127.0.0.1:8080/pets

# Add a new pet
curl -X POST http://127.0.0.1:8080/pets \
     -H "Content-Type: application/json" \
     -d '{"name": "Bond", "category": {"id": 1, "name": "Dogs"}, "status": "healthy"}'
```

As an optional feature, you can also access `<BASE_URL>/ui` (e.g., http://127.0.0.1:8080/docs) to test the APIs in a rendered Swagger UI page.
