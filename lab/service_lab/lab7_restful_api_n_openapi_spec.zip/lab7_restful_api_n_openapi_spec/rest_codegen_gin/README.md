# RESTful API with CodeGen - Gin
Generating Go Gin code from an OpenAPI YAML file.

## Requirements
- Dependencies are managed by the `go.mod` file. Set up with `go mod tidy`.

## Update OpenAPI Specification File
The `petstore.yaml` records the API specifications of how the client will interact with the server. We will use this file to generate a code stub for our backend server.

For more information on OpenAPI Specification, check here: https://swagger.io/specification/.

## Generate and Implement the Backend Server
With [oapi-codegen](https://github.com/oapi-codegen/oapi-codegen), we can generate code stubs for the Go Gin backend server.

Run the following command:
```bash
oapi-codegen --config oapi_codegen_cfg.yaml petstore.yaml
```

The generator uses a configuration file `oapi_codegen_cfg.yaml` to generate all data models and utility functions into a single file `spec.go` placed in `util/spec/petstore/`, under the `petstore` package.

Now you can implement the API functions with this generated file. In our sample implementation, MVSC pattern is used. Then, `cmd/main.go` creates an HTTP server with a Gin handler binding our implemented controller.

## Run and Test the Backend Server
To start a backend server for testing, simply run:

```bash
go run cmd/main.go
```

> If you want to build a binary program, run `go build cmd/main.go` instead of `go run`. Then, you can run `./main` without installing Go.

The server will serve on all network interfaces with port=`8080`. Below shows an output example:

```bash
# go run cmd/main.go 
[GIN-debug] [WARNING] Creating an Engine instance with the Logger and Recovery middleware already attached.

[GIN-debug] [WARNING] Running in "debug" mode. Switch to "release" mode in production.
 - using env:   export GIN_MODE=release
 - using code:  gin.SetMode(gin.ReleaseMode)

[GIN-debug] GET    /pets                     --> example/codegen/util/spec/petstore.(*ServerInterfaceWrapper).GetAllPets-fm (3 handlers)
[GIN-debug] POST   /pets                     --> example/codegen/util/spec/petstore.(*ServerInterfaceWrapper).AddPet-fm (3 handlers)
[GIN-debug] DELETE /pets/:pet_id             --> example/codegen/util/spec/petstore.(*ServerInterfaceWrapper).DeletePet-fm (3 handlers)
[GIN-debug] GET    /pets/:pet_id             --> example/codegen/util/spec/petstore.(*ServerInterfaceWrapper).GetPet-fm (3 handlers)
[GIN-debug] PUT    /pets/:pet_id             --> example/codegen/util/spec/petstore.(*ServerInterfaceWrapper).UpdatePet-fm (3 handlers)
```

To test the APIs, you can use `curl`:

```bash
# Get all pets
curl http://127.0.0.1:8080/pets

# Add a new pet
curl -X POST http://127.0.0.1:8080/pets \
     -H "Content-Type: application/json" \
     -d '{"name": "Bond", "category": {"id": 1, "name": "Dogs"}, "status": "healthy"}'
```
