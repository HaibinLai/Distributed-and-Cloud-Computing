package main

import (
	"example/codegen/controller"
	"example/codegen/service"
	"example/codegen/util/spec/petstore"
	"log"
	"net/http"

	"github.com/gin-gonic/gin"
)

func main() {
	ctrl := controller.NewController(service.NewPetService())
	router := gin.Default()
	petstore.RegisterHandlers(router, ctrl)
	s := &http.Server{
		Addr:    ":8080",
		Handler: router,
	}
	err := s.ListenAndServe()
	if err != nil {
		log.Fatalf("failed to start server: %v", err)
	}
}
