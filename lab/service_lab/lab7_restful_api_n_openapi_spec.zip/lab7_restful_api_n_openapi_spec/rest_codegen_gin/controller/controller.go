package controller

import (
	"example/codegen/service"
	"example/codegen/util/ginop"
	"example/codegen/util/spec/petstore"
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
)

type Controller struct {
	PetService *service.PetService
}

func NewController(petService *service.PetService) *Controller {
	return &Controller{
		PetService: petService,
	}
}

func (ctrl *Controller) GetAllPets(c *gin.Context) {
	pets, err := ctrl.PetService.GetAllPets(c)
	if err != nil {
		ginop.InternalServerError(c, err)
		return
	}
	c.JSON(http.StatusOK, pets)
}

func (ctrl *Controller) AddPet(c *gin.Context) {
	var req petstore.AddPetRequestBody
	if err := c.ShouldBindJSON(&req); err != nil {
		ginop.BadRequest(c, err)
		return
	}
	pet, err := ctrl.PetService.AddPet(c, req.Name, req.Category, req.Status)
	if err != nil {
		ginop.InternalServerError(c, err)
		return
	}
	c.JSON(http.StatusOK, pet)
}

func (ctrl *Controller) GetPet(c *gin.Context, petId int64) {
	if !ctrl.PetService.HasPet(petId) {
		ginop.NotFound(c, fmt.Errorf("no pet with id=%d", petId))
		return
	}
	pet, err := ctrl.PetService.GetPet(c, petId)
	if err != nil {
		ginop.InternalServerError(c, err)
		return
	}
	c.JSON(http.StatusOK, pet)
}

func (ctrl *Controller) UpdatePet(c *gin.Context, petId int64) {
	if !ctrl.PetService.HasPet(petId) {
		ginop.NotFound(c, fmt.Errorf("no pet with id=%d", petId))
		return
	}
	var req petstore.UpdatePetRequestBody
	if err := c.ShouldBindJSON(&req); err != nil {
		ginop.BadRequest(c, err)
		return
	}
	pet, err := ctrl.PetService.UpdatePet(c, petId, *req.Name, *req.Category, req.Status)
	if err != nil {
		ginop.InternalServerError(c, err)
		return
	}
	c.JSON(http.StatusOK, pet)
}

func (ctrl *Controller) DeletePet(c *gin.Context, petId int64) {
	if !ctrl.PetService.HasPet(petId) {
		ginop.NotFound(c, fmt.Errorf("no pet with id=%d", petId))
		return
	}
	petId, err := ctrl.PetService.DeletePet(c, petId)
	if err != nil {
		ginop.InternalServerError(c, err)
		return
	}
	c.JSON(http.StatusOK, petstore.DeletePetResponse{Id: petId})
}
