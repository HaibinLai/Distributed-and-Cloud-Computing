package service

import (
	"context"
	"example/codegen/util/spec/petstore"
	"fmt"
)

type PetService struct {
	Pets map[int64]*petstore.Pet
}

func NewPetService() *PetService {
	return &PetService{
		Pets: make(map[int64]*petstore.Pet),
	}
}

func (s *PetService) GetAllPets(ctx context.Context) ([]*petstore.Pet, error) {
	pets := make([]*petstore.Pet, 0, len(s.Pets))
	for _, pet := range s.Pets {
		pets = append(pets, pet)
	}
	return pets, nil
}

func (s *PetService) AddPet(ctx context.Context, name string, category petstore.Category, status *petstore.Status) (*petstore.Pet, error) {
	pet := &petstore.Pet{
		Id:       int64(len(s.Pets) + 1),
		Name:     name,
		Category: category,
		Status:   status,
	}
	s.Pets[pet.Id] = pet
	return pet, nil
}

func (s *PetService) HasPet(petId int64) bool {
	_, ok := s.Pets[petId]
	return ok
}

func (s *PetService) GetPet(ctx context.Context, petId int64) (*petstore.Pet, error) {
	pet, ok := s.Pets[petId]
	if !ok {
		return nil, fmt.Errorf("no pet with id=%d", petId)
	}
	return pet, nil
}

func (s *PetService) UpdatePet(ctx context.Context, petId int64, name string, category petstore.Category, status *petstore.Status) (*petstore.Pet, error) {
	pet, err := s.GetPet(ctx, petId)
	if err != nil {
		return nil, err
	}
	pet.Name = name
	pet.Category = category
	pet.Status = status
	return pet, nil
}

func (s *PetService) DeletePet(ctx context.Context, petId int64) (int64, error) {
	_, err := s.GetPet(ctx, petId)
	if err != nil {
		return 0, err
	}
	delete(s.Pets, petId)
	return petId, nil
}
