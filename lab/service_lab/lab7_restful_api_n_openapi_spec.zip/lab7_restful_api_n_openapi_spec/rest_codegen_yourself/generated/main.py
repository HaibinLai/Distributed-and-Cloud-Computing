def main():
    print("Hello from generated!")


if __name__ == "__main__":
    main()
