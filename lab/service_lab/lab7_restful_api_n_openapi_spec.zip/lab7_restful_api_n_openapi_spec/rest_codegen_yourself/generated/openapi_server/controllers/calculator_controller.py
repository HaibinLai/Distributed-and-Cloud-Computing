import connexion
from typing import Dict
from typing import Tuple
from typing import Union

from openapi_server.models.add_request_body import AddRequestBody  # noqa: E501
from openapi_server.models.add_result import AddResult  # noqa: E501
from openapi_server.models.mult_op import MultOp  # noqa: E501
from openapi_server.models.mult_request_body import MultRequestBody  # noqa: E501
from openapi_server import util


def add_numbers():  # noqa: E501
    """add_numbers

    Add an array of numbers. # noqa: E501

    :param add_request_body: 
    :type add_request_body: dict | bytes

    :rtype: Union[AddResult, Tuple[AddResult, int], Tuple[AddResult, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        add_request_body = AddRequestBody.from_dict(connexion.request.get_json())  # noqa: E501
    return AddResult(result=sum(add_request_body.vals)), 200


def mult():  # noqa: E501
    """mult

    Multiply two numbers. # noqa: E501

    :param mult_request_body: 
    :type mult_request_body: dict | bytes

    :rtype: Union[MultOp, Tuple[MultOp, int], Tuple[MultOp, int, Dict[str, str]]
    """
    if connexion.request.is_json:
        mult_request_body = MultRequestBody.from_dict(connexion.request.get_json())  # noqa: E501
    res = mult_request_body.xin * mult_request_body.yin
    return MultOp(xin=mult_request_body.xin, yin=mult_request_body.yin, result=res), 200
