import connexion
from typing import Dict
from typing import Tuple
from typing import Union

from openapi_server.models.greet200_response import Greet200Response  # noqa: E501
from openapi_server import util


def greet():  # noqa: E501
    """greet

    Get a Hello-World greeting. # noqa: E501


    :rtype: Union[Greet200Response, Tuple[Greet200Response, int], Tuple[Greet200Response, int, Dict[str, str]]
    """
    return {'message': 'Hello World!'}, 200


def greet_with_info(username, institution=None):  # noqa: E501
    """greet_with_info

    Get a greeting with provided name and institution. # noqa: E501

    :param username: 
    :type username: str
    :param institution: 
    :type institution: str

    :rtype: Union[Greet200Response, Tuple[Greet200Response, int], Tuple[Greet200Response, int, Dict[str, str]]
    """
    institution_segment = f' from {institution}' if institution else ''
    msg = f'Hello {username}{institution_segment}!'
    return {'message': msg}, 200
