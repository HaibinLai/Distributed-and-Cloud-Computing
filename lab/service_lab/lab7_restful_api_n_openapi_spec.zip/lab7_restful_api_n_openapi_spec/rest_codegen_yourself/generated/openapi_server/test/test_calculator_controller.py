import unittest

from flask import json

from openapi_server.models.add_request_body import AddRequestBody  # noqa: E501
from openapi_server.models.add_result import AddResult  # noqa: E501
from openapi_server.models.mult_op import MultOp  # noqa: E501
from openapi_server.models.mult_request_body import MultRequestBody  # noqa: E501
from openapi_server.test import BaseTestCase


class TestCalculatorController(BaseTestCase):
    """CalculatorController integration test stubs"""

    def test_add_numbers(self):
        """Test case for add_numbers

        
        """
        add_request_body = {"vals":[0,0]}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
        }
        response = self.client.open(
            '/calculator/add',
            method='POST',
            headers=headers,
            data=json.dumps(add_request_body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_mult(self):
        """Test case for mult

        
        """
        mult_request_body = {"xin":0.8008281904610115,"yin":6.027456183070403}
        headers = { 
            'Accept': 'application/json',
            'Content-Type': 'application/json',
        }
        response = self.client.open(
            '/calculator/mult',
            method='POST',
            headers=headers,
            data=json.dumps(mult_request_body),
            content_type='application/json')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    unittest.main()
