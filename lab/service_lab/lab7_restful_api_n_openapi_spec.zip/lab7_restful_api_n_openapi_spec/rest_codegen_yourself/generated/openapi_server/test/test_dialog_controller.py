import unittest

from flask import json

from openapi_server.models.greet200_response import Greet200Response  # noqa: E501
from openapi_server.test import BaseTestCase


class TestDialogController(BaseTestCase):
    """DialogController integration test stubs"""

    def test_greet(self):
        """Test case for greet

        
        """
        headers = { 
            'Accept': 'application/json',
        }
        response = self.client.open(
            '/',
            method='GET',
            headers=headers)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_greet_with_info(self):
        """Test case for greet_with_info

        
        """
        query_string = [('institution', 'SUSTech')]
        headers = { 
            'Accept': 'application/json',
        }
        response = self.client.open(
            '/chat/{username}'.format(username='peter'),
            method='GET',
            headers=headers,
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    unittest.main()
