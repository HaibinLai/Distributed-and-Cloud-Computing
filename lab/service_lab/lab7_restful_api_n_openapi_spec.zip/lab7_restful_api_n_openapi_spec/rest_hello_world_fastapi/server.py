from typing import Optional
from pydantic import BaseModel
from fastapi import FastAPI

app = FastAPI(
  title="Hello World",
  description="A basic example showing how to write basic RESTful APIs.",
  version="1.0.0",
  openapi_tags=[
    {
      "name": "Dialog",
      "description": "Chatting functions provided by the server"
    },
    {
      "name": "Calculator",
      "description": "Computing functions provided by the server"
    }
  ]
)


""" Objects """


class DialogResponse(BaseModel):
  """ Successful Dialog Response"""
  message: str


class MultRequestBody(BaseModel):
  """ Request Body for Multiplying two numbers. """
  xin: float
  yin: float


class MultOp(BaseModel):
  """ Response Object for Multiplying two numbers. """
  xin: float
  yin: float
  result: Optional[float] = None

  def cal(self):
    """ Calculate the result of multiplying two numbers. """
    self.result = self.xin * self.yin


""" Endpoints """


@app.get("/", response_model=DialogResponse, tags=["Dialog"])
def greet():
  """ Get a Hello-World greeting. """
  return DialogResponse(message="Hello World!")


@app.get("/chat/{username}", response_model=DialogResponse, tags=["Dialog"])
def greet_with_info(username: str, institution: Optional[str] = None):
  """ Get a greeting with provided name and institution. """
  institution_segment = f" from {institution}" if institution else ""
  return DialogResponse(message=f"Hello {username}{institution_segment}!")


@app.post("/calculator/mult", response_model=MultOp, tags=["Calculator"])
def mult(request_body: MultRequestBody):
  """ Multiply two numbers. """
  mult_op = MultOp(xin=request_body.xin, yin=request_body.yin)
  mult_op.cal()
  return mult_op
