package main

import (
	"fmt"

	"github.com/gin-gonic/gin"
)

// Objects
type MultOp struct {
	Xin    float64 `json:"xin"`
	Yin    float64 `json:"yin"`
	Result float64 `json:"result"`
}

func (op *MultOp) Cal() {
	op.Result = op.Xin * op.Yin
}

// Endpoints

func greet(c *gin.Context) {
	c.JSON(200, gin.H{
		"message": "Hello World!",
	})
}

func greetWithInfo(c *gin.Context) {
	name := c.Param("username")
	institution := c.Query("institution")
	var institutionSegment string
	if institution != "" {
		institutionSegment = fmt.Sprintf(" from %s", institution)
	}
	c.JSON(200, gin.H{
		"message": fmt.Sprintf("Hello %s%s!", name, institutionSegment),
	})
}

func mult(c *gin.Context) {
	multOp := MultOp{}
	if err := c.ShouldBindJSON(&multOp); err != nil {
		c.JSON(400, gin.H{
			"message": fmt.Sprintf("failed to bind JSON: %s", err.Error()),
		})
		return
	}
	multOp.Cal()
	c.JSON(200, multOp)
}

func main() {
	router := gin.Default()
	// Bind endpoints to router
	router.GET("/", greet)
	router.GET("/chat/:username", greetWithInfo)
	router.POST("/calculator/mult", mult)
	// Start server
	router.Run(":8081")
}
