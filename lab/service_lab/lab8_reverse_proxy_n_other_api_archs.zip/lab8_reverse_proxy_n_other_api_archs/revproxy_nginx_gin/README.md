# Reverse Proxy - Nginx with Go Gin
Test load balancing requests to 3 identical Go Gin servers.

## Requirements
- Dependencies are managed by the `gin_app/go.mod` file. Set up with `go mod tidy` inside that folder.

## Configure a Simple Gin Server
Check `gin_app/main.go`. A base URL API is implemented to return a Hello World message marking the server's name.

Check `gin_app/Dockerfile` as well. It uses a lightweight Go image, installs the Go dependencies, builds the server, and then executes the server binary. The image undergoes **multi-stage building**, where the server is first built into a binary executable file, then copied to the final execution environment. With this trick, the final image with the binary does not need to have any Go dependencies, which further **optimizes the image size**.

Build the image in advance for reuse:
```bash
docker pull golang:1.25-alpine   # do this if docker build does not work properly
docker pull alpine:3.21          # do this if docker build does not work properly
docker build -t gin_app .
```

## Configure Nginx
Check `nginx/nginx.conf`. It simply defines the set of Gin servers to forward requests to. The nginx server will listen on port `80`, using a default round-robin load balancing approach.

## Write the Docker Compose File
Check `compose.yaml`. It defines 3 Go Gin servers and 1 nginx server. The nginx server exposes port `80` to localhost so later we can access the Hello World API via web browser.

## Experiment
Start the docker compose environment via:
```bash
docker compose up -d
```

Now start a web browser and access http://localhost:80/. Refresh the page multiple times to check how the requests are load balanced to different servers in the default round-robin fashion:
```text
Hello from Gin Server 1!
Hello from Gin Server 2!
Hello from Gin Server 3!
Hello from Gin Server 1!
...
```
