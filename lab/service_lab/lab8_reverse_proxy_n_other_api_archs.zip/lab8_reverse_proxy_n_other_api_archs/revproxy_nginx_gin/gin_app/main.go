package main

import (
	"fmt"
	"os"

	"github.com/gin-gonic/gin"
)

// Utility functions (I'm lazy so they are separated to another file =.=)

func getEnvWithDefault(key, defaultVal string) string {
	if val, ok := os.LookupEnv(key); ok {
		return val
	}
	return defaultVal
}

// Endpoints

func greet(c *gin.Context) {
	serverName := getEnvWithDefault("SERVER_NAME", "Unknown Server")
	c.JSON(200, gin.H{
		"message": fmt.Sprintf("Hello from %s!", serverName),
	})
}

func main() {
	router := gin.Default()
	// Bind endpoints to router
	router.GET("/", greet)
	// Start server
	port := getEnvWithDefault("GIN_PORT", "8081")
	router.Run(fmt.Sprintf(":%s", port))
}
